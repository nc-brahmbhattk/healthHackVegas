# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

from .models import Drink

admin.site.register(Drink)
# Register your models here.
