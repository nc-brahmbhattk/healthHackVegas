from django.conf.urls import url
from . import views
app_name = 'activities'
urlpatterns = [
    url(r'^$', views.activity_list, name='activity_list')
]
