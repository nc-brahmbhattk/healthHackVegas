# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from .models import Activity

def activity_list(request):
    activity_list = Activity.objects.all().order_by('date')
    context = {
                'activity_list':activity_list
    }
    return render(request, 'activities/activities_list.html', context)
# Create your views here.
